//
//  main.m
//  Luxury Shoes for men
//
//  Created by Gadgets Planet on 25/10/18.
//  Copyright © 2018 mcclab. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
